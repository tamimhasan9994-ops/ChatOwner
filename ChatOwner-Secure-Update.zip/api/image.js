import { GoogleGenAI } from "@google/genai";
import { cors, requireUser } from "./_lib/auth.js";
export default async function handler(req,res){
  cors(res); if(req.method==="OPTIONS")return res.status(204).end();
  if(req.method!=="POST")return res.status(405).json({error:"Method not allowed"});
  try{
    await requireUser(req); const {prompt}=req.body||{}; if(!prompt)return res.status(400).json({error:"Prompt required"});
    const ai=new GoogleGenAI({apiKey:process.env.GEMINI_API_KEY});
    const response=await ai.models.generateContent({
      model:process.env.GEMINI_IMAGE_MODEL||"gemini-3.1-flash-image",
      contents:prompt,
      config:{responseModalities:["TEXT","IMAGE"]}
    });
    for(const part of response.candidates?.[0]?.content?.parts||[]){
      if(part.inlineData?.data)return res.json({mimeType:part.inlineData.mimeType||"image/png",data:part.inlineData.data});
    }
    throw new Error("No image was returned.");
  }catch(e){console.error(e);res.status(400).json({error:e.message||"Image generation failed"})}
}