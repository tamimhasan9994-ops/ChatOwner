import { GoogleGenAI } from "@google/genai";
import { db, cors, requireUser } from "./_lib/auth.js";

export default async function handler(req,res){
  cors(res);
  if(req.method==="OPTIONS") return res.status(204).end();
  if(req.method!=="POST") return res.status(405).json({error:"Method not allowed"});
  try{
    const user=await requireUser(req);
    const {contents,systemInstruction}=req.body||{};
    if(!contents) return res.status(400).json({error:"Missing contents"});
    const ai=new GoogleGenAI({apiKey:process.env.GEMINI_API_KEY});
    const response=await ai.models.generateContent({
      model:process.env.GEMINI_TEXT_MODEL||"gemini-3.1-flash-lite",
      contents,
      config:{systemInstruction,temperature:0.3,maxOutputTokens:4096}
    });
    const answer=response.text||"The AI returned an empty answer.";
    await db.collection("users").doc(user.uid).collection("history").add({
      question:contents.at(-1)?.parts?.find(p=>p.text)?.text||"Image question",
      answer, createdAt:new Date().toISOString()
    });
    return res.status(200).json({answer});
  }catch(e){console.error(e);return res.status(401).json({error:e.message||"Server error"})}
}