import { cors, requireUser } from "./_lib/auth.js";
export default async function handler(req,res){
  cors(res); if(req.method==="OPTIONS")return res.status(204).end();
  if(req.method!=="POST")return res.status(405).json({error:"Method not allowed"});
  try{
    await requireUser(req); const {prompt}=req.body||{}; if(!prompt)return res.status(400).json({error:"Prompt required"});
    const model=process.env.GEMINI_VIDEO_MODEL||"veo-3.1-fast-generate-preview";
    const r=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:predictLongRunning`,{
      method:"POST",headers:{"Content-Type":"application/json","x-goog-api-key":process.env.GEMINI_API_KEY},
      body:JSON.stringify({instances:[{prompt}],parameters:{aspectRatio:"16:9",resolution:"720p"}})
    });
    const d=await r.json(); if(!r.ok)throw new Error(d.error?.message||"Video generation failed");
    return res.json({operation:d.name});
  }catch(e){console.error(e);res.status(400).json({error:e.message||"Video generation failed"})}
}