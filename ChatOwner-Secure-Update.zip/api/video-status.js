import { cors, requireUser } from "./_lib/auth.js";
export default async function handler(req,res){
  cors(res); if(req.method==="OPTIONS")return res.status(204).end();
  if(req.method!=="POST")return res.status(405).json({error:"Method not allowed"});
  try{
    await requireUser(req); const {operation}=req.body||{}; if(!operation)return res.status(400).json({error:"Operation required"});
    const url=`https://generativelanguage.googleapis.com/v1beta/${operation}`;
    const r=await fetch(url,{headers:{"x-goog-api-key":process.env.GEMINI_API_KEY}});
    const d=await r.json(); if(!r.ok)throw new Error(d.error?.message||"Status check failed");
    if(!d.done)return res.json({done:false,status:"Generating video..."});
    const uri=d.response?.generateVideoResponse?.generatedSamples?.[0]?.video?.uri;
    if(!uri)return res.json({done:true,status:"Completed, but no video URI was returned."});
    const vr=await fetch(uri,{headers:{"x-goog-api-key":process.env.GEMINI_API_KEY}});
    if(!vr.ok)throw new Error("Video download failed");
    const buf=Buffer.from(await vr.arrayBuffer());
    return res.json({done:true,status:"Video ready ✓",videoData:buf.toString("base64")});
  }catch(e){console.error(e);res.status(400).json({error:e.message||"Video status failed"})}
}