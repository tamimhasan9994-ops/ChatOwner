import { db, cors, requireUser } from "./_lib/auth.js";
export default async function handler(req,res){
  cors(res); if(req.method==="OPTIONS")return res.status(204).end();
  if(req.method!=="GET")return res.status(405).json({error:"Method not allowed"});
  try{
    const user=await requireUser(req);
    const snap=await db.collection("users").doc(user.uid).collection("history").orderBy("createdAt","desc").limit(50).get();
    return res.json({items:snap.docs.map(d=>({id:d.id,...d.data()}))});
  }catch(e){console.error(e);res.status(400).json({error:e.message||"History failed"})}
}