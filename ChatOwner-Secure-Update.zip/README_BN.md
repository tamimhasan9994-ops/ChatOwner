# ChatOwner Secure Update

এই package-এ frontend + secure Vercel backend প্রস্তুত করা হয়েছে।

## কী বদলেছে
- API key আর `index.html`-এ নেই।
- Firebase Email/Password Login/Signup.
- User-specific Firestore history.
- Bangla/Banglish/English question solver.
- Image question solver.
- Nano Banana image generation.
- Veo video generation workflow.
- Settings UI বাদ।
- Mobile-first UI.

## গুরুত্বপূর্ণ
1. `public/index.html`-এ Firebase Web config বসাও।
2. Backend Vercel-এ deploy করে Environment Variables-এ Gemini key ও Firebase Service Account JSON রাখো।
3. `API_BASE`-এ backend URL বসাও।
4. Firebase Authentication-এ Email/Password enable করো এবং Firestore চালু করো।
5. Firestore rules এমন রাখো যেন client সরাসরি user history না লিখতে পারে; backend Admin SDK দিয়ে লেখে।

## Video
Veo 3.1 একবারে 4/6/8-second clip দেয়। তাই UI-তে 30-second single-generation দাবি করা হয়নি। 30 seconds দরকার হলে পরে একটি extension/clip-assembly workflow যোগ করতে হবে এবং এটি paid quota/cost-এর ওপর নির্ভর করবে.

## Deploy
- Backend: Vercel
- Frontend: GitHub Pages
